
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://wofrapotgmemnsldjbso.supabase.co';
const supabaseKey = 'sb_publishable__sBikwQ7bbUChkATT1NOeA_i3xpHJ6b';

export const supabase = createClient(supabaseUrl, supabaseKey);
