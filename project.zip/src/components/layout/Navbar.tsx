
"use client";

import { LogOut, User, Bell, Menu, LayoutDashboard, Wallet, Repeat, Shield, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import { useUser, useDoc, useAuth } from "@/firebase";
import { signOut } from "firebase/auth";

export function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useUser();
  const auth = useAuth();
  const userDoc = useDoc(user ? `users/${user.uid}` : null);
  const profile = userDoc?.data;

  // Hardcoded Admin Email for permanent access
  const isAdmin = profile?.role === 'admin' || user?.email === 'asif1asif7asof@gmail.com';

  const navItems = [
    { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { label: "Deposit", href: "/deposit", icon: Wallet },
    { label: "Withdraw", href: "/withdraw", icon: Repeat },
    { label: "History", href: "/transactions", icon: Repeat },
    { label: "Rules", href: "/rules", icon: FileText },
  ];

  const handleLogout = async () => {
    if (auth) {
      await signOut(auth);
      router.push("/auth/login");
    }
  };

  return (
    <nav className="border-b border-white/5 bg-background/95 backdrop-blur sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center font-headline font-bold text-white text-xs">OE</div>
            <span className="text-lg font-headline font-bold text-white hidden sm:inline-block">OPEN<span className="text-primary">EXCHANGE</span></span>
          </Link>

          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className={cn(
                    "text-muted-foreground hover:text-primary hover:bg-primary/5 gap-2",
                    pathname === item.href && "text-primary bg-primary/5"
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Button>
              </Link>
            ))}
            {isAdmin && (
              <Link href="/admin">
                <Button 
                  variant="ghost" 
                  size="sm"
                  className={cn(
                    "text-amber-500 hover:text-amber-400 hover:bg-amber-500/5 gap-2",
                    pathname === "/admin" && "bg-amber-500/10"
                  )}
                >
                  <Shield className="h-4 w-4" />
                  Admin
                </Button>
              </Link>
            )}
          </div>
        </div>

        <div className="flex items-center gap-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-auto px-2 rounded-lg hover:bg-white/5 gap-3">
                <div className="hidden sm:flex flex-col items-end mr-1">
                  <span className="text-xs font-bold text-white leading-none">{profile?.name || "Player"}</span>
                  <span className="text-[10px] text-primary leading-none mt-1 uppercase">{isAdmin ? "admin" : "user"}</span>
                </div>
                <Avatar className="h-8 w-8 border border-primary/20">
                  <AvatarFallback className="bg-primary/10 text-primary uppercase">
                    {profile?.name?.substring(0, 2) || "PL"}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 glass-card border-white/10" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{profile?.name}</p>
                  <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-white/5" />
              <DropdownMenuItem asChild>
                <Link href="/profile" className="flex items-center cursor-pointer">
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile Settings</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/transactions" className="flex items-center cursor-pointer">
                  <Wallet className="mr-2 h-4 w-4" />
                  <span>My Transactions</span>
                </Link>
              </DropdownMenuItem>
              {isAdmin && (
                <DropdownMenuItem asChild>
                  <Link href="/admin" className="flex items-center cursor-pointer text-amber-500">
                    <Shield className="mr-2 h-4 w-4" />
                    <span>Admin Panel</span>
                  </Link>
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator className="bg-white/5" />
              <DropdownMenuItem 
                onClick={handleLogout}
                className="text-destructive focus:bg-destructive/10 cursor-pointer"
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="ghost" size="icon" className="md:hidden text-white">
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </nav>
  );
}
