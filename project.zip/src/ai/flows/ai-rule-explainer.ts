'use server';
/**
 * @fileOverview An AI assistant that helps users understand complex rules and policies.
 *
 * - aiRuleExplainer - A function that handles explaining rules based on provided policy texts.
 * - AIRuleExplainerInput - The input type for the aiRuleExplainer function.
 * - AIRuleExplainerOutput - The return type for the aiRuleExplainer function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIRuleExplainerInputSchema = z.object({
  question: z.string().describe('The user\'s question about the rules or policies.'),
  policies: z
    .array(z.string())
    .describe('An array of policy texts that the AI should use as context to answer the question.'),
});
export type AIRuleExplainerInput = z.infer<typeof AIRuleExplainerInputSchema>;

const AIRuleExplainerOutputSchema = z.object({
  answer: z
    .string()
    .describe('A concise answer to the user\'s question based on the provided policies.'),
});
export type AIRuleExplainerOutput = z.infer<typeof AIRuleExplainerOutputSchema>;

export async function aiRuleExplainer(
  input: AIRuleExplainerInput
): Promise<AIRuleExplainerOutput> {
  return aiRuleExplainerFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiRuleExplainerPrompt',
  input: {schema: AIRuleExplainerInputSchema},
  output: {schema: AIRuleExplainerOutputSchema},
  prompt: `You are an AI assistant specialized in explaining rules and policies.
Your task is to answer the user's question concisely based *only* on the provided policy texts.
If the answer cannot be found in the provided policies, state that you cannot answer based on the given information.

Policies:
{{#each policies}}
--- Policy ---
{{{this}}}
--- End Policy ---
{{/each}}

Question: {{{question}}}
Answer:`,
});

const aiRuleExplainerFlow = ai.defineFlow(
  {
    name: 'aiRuleExplainerFlow',
    inputSchema: AIRuleExplainerInputSchema,
    outputSchema: AIRuleExplainerOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
