import { config } from 'dotenv';
config();

import '@/ai/flows/ai-rule-explainer.ts';