
"use client";

import { useUser, useDoc, useCollection, useFirestore } from "@/firebase";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, X, Shield, RefreshCcw, Users, Search, DollarSign, ArrowRightLeft, Key, UserPlus } from "lucide-react";
import { collection, query, where, orderBy, updateDoc, doc, increment, deleteDoc } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { useRouter } from "next/navigation";
import { useMemo, useState, useEffect } from "react";
import { Input } from "@/components/ui/input";

export default function AdminPanel() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState("");
  
  const userDoc = useDoc(user ? `users/${user.uid}` : null);
  const profile = userDoc?.data;

  // Protect Admin route + Auto-promote specified email
  const isAdmin = profile?.role === "admin" || user?.email === "asif1asif7asof@gmail.com";

  useEffect(() => {
    if (user?.email === "asif1asif7asof@gmail.com" && profile && profile.role !== "admin" && db) {
      updateDoc(doc(db, "users", user.uid), { role: "admin" });
    }
  }, [user, profile, db]);

  if (profile && !isAdmin) {
    router.push("/dashboard");
    return null;
  }

  const pendingDepositsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, "deposits"), where("status", "==", "pending"), orderBy("timestamp", "desc"));
  }, [db]);

  const pendingWithdrawalsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, "withdrawals"), where("status", "==", "pending"), orderBy("timestamp", "desc"));
  }, [db]);

  const usersQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, "users"), orderBy("createdAt", "desc"));
  }, [db]);

  const playRequestsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, "play_requests"), where("status", "==", "pending"), orderBy("timestamp", "desc"));
  }, [db]);

  const { data: deposits } = useCollection(pendingDepositsQuery);
  const { data: withdrawals } = useCollection(pendingWithdrawalsQuery);
  const { data: allUsers } = useCollection(usersQuery);
  const { data: playRequests } = useCollection(playRequestsQuery);

  const filteredUsers = useMemo(() => {
    if (!allUsers) return [];
    return allUsers.filter(u => 
      u.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
      u.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.uid?.includes(searchTerm)
    );
  }, [allUsers, searchTerm]);

  const handleDepositAction = async (depositId: string, userId: string, amount: number, action: "approved" | "rejected") => {
    if (!db) return;
    try {
      await updateDoc(doc(db, "deposits", depositId), { status: action });
      
      if (action === "approved") {
        await updateDoc(doc(db, "users", userId), { balance: increment(amount) });
        toast({ title: "Deposit Approved", description: `Added PKR ${amount} to user balance.` });
      } else {
        toast({ title: "Deposit Rejected", description: "Request has been declined." });
      }
    } catch (e: any) {
      toast({ variant: "destructive", title: "Action Failed", description: e.message });
    }
  };

  const handleWithdrawAction = async (withdrawId: string, userId: string, amount: number, action: "approved" | "rejected") => {
    if (!db) return;
    try {
      await updateDoc(doc(db, "withdrawals", withdrawId), { status: action });
      
      if (action === "rejected") {
        await updateDoc(doc(db, "users", userId), { balance: increment(amount) });
        toast({ title: "Withdrawal Rejected", description: `Refunded PKR ${amount} to user balance.` });
      } else {
        toast({ title: "Withdrawal Approved", description: "Request marked as completed." });
      }
    } catch (e: any) {
      toast({ variant: "destructive", title: "Action Failed", description: e.message });
    }
  };

  const handleAssignPlayId = async (requestId: string, userId: string) => {
    if (!db) return;
    const playId = prompt("Enter Exchange Login ID:");
    const playPassword = prompt("Enter Exchange Password:");
    
    if (!playId || !playPassword) return;

    try {
      await updateDoc(doc(db, "users", userId), { playId, playPassword });
      await updateDoc(doc(db, "play_requests", requestId), { status: "completed" });
      toast({ title: "Access Granted", description: "ID and Password sent to user dashboard." });
    } catch (e: any) {
      toast({ variant: "destructive", title: "Action Failed", description: e.message });
    }
  };

  const adjustBalance = async (userId: string, currentBalance: number) => {
    const input = prompt(`Current Balance: PKR ${currentBalance}. Enter new balance:`, currentBalance.toString());
    if (input === null || isNaN(parseFloat(input))) return;
    
    const newBalance = parseFloat(input);
    if (!db) return;
    try {
      await updateDoc(doc(db, "users", userId), { balance: newBalance });
      toast({ title: "Balance Updated", description: `User balance set to PKR ${newBalance}.` });
    } catch (e: any) {
      toast({ variant: "destructive", title: "Update Failed", description: e.message });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      <header className="py-8 bg-secondary/20 border-b border-white/5">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-headline font-bold text-white">Admin Control Panel</h1>
              <p className="text-muted-foreground">Manage platform operations and user accounts.</p>
            </div>
          </div>
          <Button variant="outline" className="gap-2" onClick={() => window.location.reload()}>
            <RefreshCcw className="h-4 w-4" />
            Refresh
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <Tabs defaultValue="deposits" className="w-full">
          <TabsList className="flex flex-wrap h-auto gap-2 bg-transparent mb-8">
            <TabsTrigger value="deposits" className="glass-card data-[state=active]:bg-primary">
              <DollarSign className="h-4 w-4 mr-2" />
              Deposits ({deposits?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="withdrawals" className="glass-card data-[state=active]:bg-primary">
              <ArrowRightLeft className="h-4 w-4 mr-2" />
              Withdrawals ({withdrawals?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="play_requests" className="glass-card data-[state=active]:bg-primary">
              <Key className="h-4 w-4 mr-2" />
              Play Requests ({playRequests?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="users" className="glass-card data-[state=active]:bg-primary">
              <Users className="h-4 w-4 mr-2" />
              Users
            </TabsTrigger>
          </TabsList>

          <TabsContent value="deposits">
            <div className="grid grid-cols-1 gap-4">
              {deposits && deposits.length > 0 ? (
                deposits.map((d) => (
                  <Card key={d.id} className="glass-card">
                    <CardContent className="p-6 flex flex-col md:flex-row items-center justify-between gap-6">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Badge className="bg-primary/20 text-primary border-primary/20 text-lg">PKR {d.amount}</Badge>
                          <span className="text-white font-bold">{d.method}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">TID: <span className="text-white font-mono">{d.tid}</span></p>
                        <p className="text-xs text-muted-foreground">User UID: {d.uid} | {new Date(d.timestamp).toLocaleString()}</p>
                      </div>
                      <div className="flex gap-3">
                        <Button 
                          onClick={() => handleDepositAction(d.id, d.uid, d.amount, "approved")}
                          className="bg-primary hover:bg-primary/90 text-white gap-2 px-6"
                        >
                          <Check className="h-4 w-4" /> Approve
                        </Button>
                        <Button 
                          variant="destructive"
                          onClick={() => handleDepositAction(d.id, d.uid, d.amount, "rejected")}
                          className="gap-2"
                        >
                          <X className="h-4 w-4" /> Reject
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-20 text-muted-foreground bg-white/5 rounded-xl border border-dashed border-white/10">No pending deposits.</div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="withdrawals">
            <div className="grid grid-cols-1 gap-4">
              {withdrawals && withdrawals.length > 0 ? (
                withdrawals.map((w) => (
                  <Card key={w.id} className="glass-card">
                    <CardContent className="p-6 flex flex-col md:flex-row items-center justify-between gap-6">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Badge className="bg-destructive/20 text-destructive border-destructive/20 text-lg">PKR {w.amount}</Badge>
                          <span className="text-white font-bold">{w.method}</span>
                        </div>
                        <p className="text-sm text-white font-mono">{w.details}</p>
                        <p className="text-xs text-muted-foreground">User UID: {w.uid} | {new Date(w.timestamp).toLocaleString()}</p>
                      </div>
                      <div className="flex gap-3">
                        <Button 
                          onClick={() => handleWithdrawAction(w.id, w.uid, w.amount, "approved")}
                          className="bg-primary hover:bg-primary/90 text-white gap-2 px-6"
                        >
                          <Check className="h-4 w-4" /> Mark as Paid
                        </Button>
                        <Button 
                          variant="destructive"
                          onClick={() => handleWithdrawAction(w.id, w.uid, w.amount, "rejected")}
                          className="gap-2"
                        >
                          <X className="h-4 w-4" /> Reject
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-20 text-muted-foreground bg-white/5 rounded-xl border border-dashed border-white/10">No pending withdrawals.</div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="play_requests">
            <div className="grid grid-cols-1 gap-4">
              {playRequests && playRequests.length > 0 ? (
                playRequests.map((r) => (
                  <Card key={r.id} className="glass-card">
                    <CardContent className="p-6 flex flex-col md:flex-row items-center justify-between gap-6">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Badge className="bg-accent/20 text-accent border-accent/20">Play ID Request</Badge>
                          <span className="text-white font-bold">{r.userName}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">UID: {r.uid} | {new Date(r.timestamp).toLocaleString()}</p>
                      </div>
                      <div className="flex gap-3">
                        <Button 
                          onClick={() => handleAssignPlayId(r.id, r.uid)}
                          className="bg-primary hover:bg-primary/90 text-white gap-2 px-6"
                        >
                          <UserPlus className="h-4 w-4" /> Assign Credentials
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-20 text-muted-foreground bg-white/5 rounded-xl border border-dashed border-white/10">No pending Play ID requests.</div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="users">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle>User List</CardTitle>
                <CardDescription>View and manage all registered users.</CardDescription>
                <div className="relative mt-4">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search by name, email or UID..." 
                    className="pl-10 bg-background"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredUsers.length > 0 ? (
                    filteredUsers.map((u) => (
                      <div key={u.id} className="flex items-center justify-between p-4 border border-white/5 rounded-lg hover:bg-white/5 transition-colors">
                        <div>
                          <p className="font-bold text-white">{u.name}</p>
                          <p className="text-sm text-muted-foreground">{u.email}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-[10px]">{u.role}</Badge>
                            <span className="text-xs text-muted-foreground">Balance: PKR {u.balance}</span>
                          </div>
                          {u.playId && (
                            <p className="text-[10px] text-primary mt-1">Play ID: {u.playId}</p>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => adjustBalance(u.uid, u.balance)}
                            className="text-xs h-8"
                          >
                            Edit Balance
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-10 text-muted-foreground italic">No users found.</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
