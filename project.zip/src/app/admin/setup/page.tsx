
"use client";

import { useState } from "react";
import { useUser, useDoc, useFirestore } from "@/firebase";
import { doc, updateDoc } from "firebase/firestore";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ShieldCheck, AlertTriangle } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { useToast } from "@/hooks/use-toast";
import { useRouter } from "next/navigation";

export default function AdminSetup() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const router = useRouter();
  const userDoc = useDoc(user ? `users/${user.uid}` : null);
  const profile = userDoc?.data;
  const [loading, setLoading] = useState(false);

  const makeMeAdmin = async () => {
    if (!user || !db) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, "users", user.uid), {
        role: "admin"
      });
      toast({
        title: "Success!",
        description: "You are now an Administrator.",
      });
      router.push("/admin");
    } catch (e: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: e.message,
      });
    } finally {
      setLoading(false);
    }
  };

  if (!user) return <div className="p-20 text-center">Please login first.</div>;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-20 flex justify-center">
        <Card className="max-w-md w-full glass-card border-primary/20">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4">
              <ShieldCheck className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl font-headline">Admin Promotion</CardTitle>
            <CardDescription>Click below to grant your account administrative privileges for testing.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg flex gap-3 text-amber-500">
              <AlertTriangle className="h-5 w-5 shrink-0" />
              <p className="text-xs">Warning: Admin access allows full control over users, balances, and transactions.</p>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Current Account: <span className="text-white font-bold">{user.email}</span></p>
              <p className="text-sm text-muted-foreground">Current Role: <span className="text-primary font-bold uppercase">{profile?.role || "User"}</span></p>
            </div>

            <Button 
              onClick={makeMeAdmin} 
              disabled={loading || profile?.role === 'admin'} 
              className="w-full h-12 text-lg font-bold bg-primary hover:bg-primary/90 text-white"
            >
              {profile?.role === 'admin' ? "Already Admin" : loading ? "Promoting..." : "Become Administrator"}
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
