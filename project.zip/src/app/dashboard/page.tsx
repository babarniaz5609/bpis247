
"use client";

import { Navbar } from "@/components/layout/Navbar";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { 
  TrendingUp, 
  Wallet, 
  Play, 
  ArrowUpRight, 
  ArrowDownRight,
  Gamepad2,
  Trophy,
  Bell,
  HelpCircle,
  Users,
  Key,
  AlertTriangle,
  MailWarning
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { useUser, useDoc, useCollection, useFirestore } from "@/firebase";
import { cn } from "@/lib/utils";
import { collection, query, where, orderBy, limit, addDoc, updateDoc, doc } from "firebase/firestore";
import { useMemo, useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [requestLoading, setRequestLoading] = useState(false);
  
  const userDoc = useDoc(user ? `users/${user.uid}` : null);
  const profile = userDoc?.data;

  // Auto-promote asif1asif7asof@gmail.com to admin role in Firestore
  useEffect(() => {
    if (user?.email === "asif1asif7asof@gmail.com" && profile && profile.role !== "admin" && db) {
      updateDoc(doc(db, "users", user.uid), { role: "admin" });
    }
  }, [user, profile, db]);

  const isAdmin = profile?.role === 'admin' || user?.email === 'asif1asif7asof@gmail.com';

  const depositsQuery = useMemo(() => {
    if (!db || !user) return null;
    return query(
      collection(db, "deposits"),
      where("uid", "==", user.uid),
      orderBy("timestamp", "desc"),
      limit(5)
    );
  }, [db, user]);

  const { data: recentDeposits } = useCollection(depositsQuery);

  const handleRequestAccess = async () => {
    if (!db || !user || !profile) return;
    setRequestLoading(true);
    try {
      await addDoc(collection(db, "play_requests"), {
        uid: user.uid,
        userName: profile.name,
        status: "pending",
        timestamp: new Date().toISOString()
      });
      toast({
        title: "Request Sent",
        description: "Admin will provide your exchange ID and Password soon.",
      });
    } catch (e: any) {
      toast({ variant: "destructive", title: "Request Failed", description: e.message });
    } finally {
      setRequestLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Please log in to view your dashboard.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        {!user.emailVerified && (
          <div className="mb-8 p-4 bg-destructive/10 border border-destructive/20 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3 text-destructive">
              <MailWarning className="h-5 w-5" />
              <p className="text-sm font-medium">Please verify your email address to ensure full account security.</p>
            </div>
          </div>
        )}

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
          <div>
            <h1 className="text-3xl font-headline font-bold text-white mb-1">
              Welcome back, {profile?.name || "Player"}
            </h1>
            <p className="text-muted-foreground">
              Account Status: 
              <Badge variant="default" className={cn(
                "ml-2 border-primary/20",
                isAdmin ? "bg-amber-500/20 text-amber-500" : "bg-primary/20 text-primary"
              )}>
                {isAdmin ? 'Administrator' : 'Active'}
              </Badge>
            </p>
          </div>
          
          <div className="flex gap-4">
            <Link href="/deposit">
              <Button className="bg-primary hover:bg-primary/90 text-white gap-2 h-11 px-6">
                <ArrowUpRight className="h-4 w-4" />
                Deposit
              </Button>
            </Link>
            <Link href="/withdraw">
              <Button variant="outline" className="border-white/10 hover:bg-white/5 text-white gap-2 h-11 px-6">
                <ArrowDownRight className="h-4 w-4" />
                Withdraw
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm font-medium text-muted-foreground">Total Balance</p>
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Wallet className="h-4 w-4 text-primary" />
                </div>
              </div>
              <p className="text-3xl font-bold text-white">PKR {profile?.balance?.toLocaleString() || "0.00"}</p>
              <div className="flex items-center mt-2 text-xs text-primary">
                <TrendingUp className="h-3 w-3 mr-1" />
                <span>Ready to play</span>
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm font-medium text-muted-foreground">User ID</p>
                <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center">
                  <Users className="h-4 w-4 text-accent" />
                </div>
              </div>
              <p className="text-xl font-bold text-white font-mono">{user.uid.substring(0, 8)}...</p>
              <p className="text-xs text-muted-foreground mt-2">Verified Account</p>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm font-medium text-muted-foreground">Referral Code</p>
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Trophy className="h-4 w-4 text-primary" />
                </div>
              </div>
              <p className="text-xl font-bold text-white font-mono">{profile?.referralCode || "N/A"}</p>
              <p className="text-xs text-muted-foreground mt-2">Earn bonus on every referral</p>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm font-medium text-muted-foreground">Active Sessions</p>
                <div className="w-8 h-8 rounded-full bg-destructive/10 flex items-center justify-center">
                  <Gamepad2 className="h-4 w-4 text-destructive" />
                </div>
              </div>
              <p className="text-3xl font-bold text-white">1</p>
              <p className="text-xs text-muted-foreground mt-2">Current device</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Exchange Credentials Card */}
            <Card className="glass-card border-primary/20 bg-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5 text-primary" />
                  Exchange Credentials
                </CardTitle>
                <CardDescription>Your login details for BP Exchange.</CardDescription>
              </CardHeader>
              <CardContent>
                {profile?.playId ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-background rounded-lg border border-white/5">
                      <p className="text-xs text-muted-foreground uppercase mb-1">Exchange ID</p>
                      <p className="text-lg font-bold text-white font-mono">{profile.playId}</p>
                    </div>
                    <div className="p-4 bg-background rounded-lg border border-white/5">
                      <p className="text-xs text-muted-foreground uppercase mb-1">Exchange Password</p>
                      <p className="text-lg font-bold text-white font-mono">{profile.playPassword}</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <p className="text-sm text-muted-foreground mb-4">You don't have an Exchange ID yet.</p>
                    <Button 
                      onClick={handleRequestAccess} 
                      disabled={requestLoading}
                      variant="outline"
                      className="border-primary/20 text-primary hover:bg-primary/10"
                    >
                      {requestLoading ? "Requesting..." : "Request Play ID & Password"}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden border-none shadow-2xl group">
              <div className="absolute inset-0 bg-gradient-to-r from-[#009933] to-[#004d1a] opacity-90" />
              <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/bet/800/400')] bg-cover bg-center mix-blend-overlay group-hover:scale-105 transition-transform duration-700" />
              <CardContent className="relative z-10 p-10 flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="text-center md:text-left">
                  <h2 className="text-4xl font-headline font-bold text-white mb-4">Ready to Play?</h2>
                  <p className="text-white/80 max-w-sm mb-6">
                    Connect to BP Exchange now and start betting with the highest limits in the industry.
                  </p>
                  <div className="flex flex-col gap-2">
                    <a 
                      href="https://bpexch.live/Users/Login" 
                      target="_blank" 
                      rel="noopener noreferrer"
                    >
                      <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-bold px-8 h-14 rounded-full shadow-lg">
                        <Play className="mr-2 h-5 w-5 fill-current" />
                        Play on BP Exchange
                      </Button>
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-headline font-bold text-white">Recent Deposits</h3>
                <Link href="/transactions">
                  <Button variant="link" className="text-primary p-0">View all history</Button>
                </Link>
              </div>
              <div className="glass-card rounded-xl overflow-hidden">
                {recentDeposits && recentDeposits.length > 0 ? (
                  recentDeposits.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-4 border-b border-white/5 hover:bg-white/5 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full flex items-center justify-center bg-primary/10">
                          <ArrowUpRight className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-white">Deposit via {tx.method}</p>
                          <p className="text-xs text-muted-foreground">{new Date(tx.timestamp).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-white">PKR {tx.amount}</p>
                        <Badge variant="outline" className={cn(
                          "text-[10px] uppercase",
                          tx.status === 'approved' ? "text-primary border-primary/20 bg-primary/5" : 
                          tx.status === 'pending' ? "text-amber-500 border-amber-500/20 bg-amber-500/5" :
                          "text-destructive border-destructive/20 bg-destructive/5"
                        )}>
                          {tx.status}
                        </Badge>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center text-muted-foreground">No recent transactions.</div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <Card className="glass-card border-none">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Bell className="h-4 w-4 text-accent" />
                  Announcements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-white/5 rounded-lg border border-white/5 group hover:border-primary/20 transition-all cursor-pointer">
                  <h4 className="text-sm font-bold text-white mb-1 group-hover:text-primary transition-colors">Instant Withdrawals Active</h4>
                  <p className="text-xs text-muted-foreground">Withdrawals now processing in under 2 hours.</p>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-none bg-accent/5">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <HelpCircle className="h-4 w-4 text-accent" />
                  Need Help?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">Our dedicated team is available 24/7 to assist you.</p>
                <Link href="https://wa.me/212782563750" target="_blank">
                  <Button className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white">Contact WhatsApp</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <WhatsAppButton />
    </div>
  );
}
