
"use client";

import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { Repeat, Smartphone, Landmark, AlertCircle, Coins } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useUser, useDoc, useFirestore } from "@/firebase";
import { collection, addDoc, serverTimestamp, updateDoc, doc, increment } from "firebase/firestore";
import { useRouter } from "next/navigation";

export default function WithdrawPage() {
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("JazzCash");
  const [details, setDetails] = useState("");
  const [loading, setLoading] = useState(false);
  
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const router = useRouter();
  
  const userDoc = useDoc(user ? `users/${user.uid}` : null);
  const profile = userDoc?.data;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !db || !profile) return;

    const withdrawAmount = parseFloat(amount);
    if (isNaN(withdrawAmount) || withdrawAmount < 1000) {
      toast({ variant: "destructive", title: "Invalid Amount", description: "Minimum withdrawal is 1,000 PKR." });
      return;
    }

    if (withdrawAmount > profile.balance) {
      toast({ variant: "destructive", title: "Insufficient Balance", description: "You don't have enough balance for this withdrawal." });
      return;
    }

    setLoading(true);
    try {
      // Create withdrawal request
      await addDoc(collection(db, "withdrawals"), {
        uid: user.uid,
        amount: withdrawAmount,
        method,
        details,
        status: "pending",
        timestamp: new Date().toISOString()
      });

      // Deduct balance temporarily
      await updateDoc(doc(db, "users", user.uid), {
        balance: increment(-withdrawAmount)
      });

      toast({
        title: "Request Submitted",
        description: "Your withdrawal is being processed. Expected time: 2 hours.",
      });
      router.push("/dashboard");
    } catch (e: any) {
      toast({ variant: "destructive", title: "Request Failed", description: e.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
              <Repeat className="h-6 w-6 text-destructive" />
            </div>
            <div>
              <h1 className="text-3xl font-headline font-bold text-white">Withdraw Funds</h1>
              <p className="text-muted-foreground">Cash out your winnings securely.</p>
            </div>
          </div>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Withdrawal Request</CardTitle>
              <CardDescription>
                Available Balance: <span className="text-white font-bold">PKR {profile?.balance?.toLocaleString() || "0"}</span>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount (PKR)</Label>
                  <Input 
                    id="amount" 
                    type="number" 
                    placeholder="Min 1,000" 
                    className="bg-background"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Payment Method</Label>
                  <div className="grid grid-cols-2 gap-3">
                    {["JazzCash", "Easypaisa", "Bank Transfer", "Crypto"].map((m) => (
                      <Button
                        key={m}
                        type="button"
                        variant={method === m ? "default" : "outline"}
                        className={method === m ? "bg-primary" : "border-white/10"}
                        onClick={() => setMethod(m)}
                      >
                        {m}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="details">Account Details</Label>
                  <Input 
                    id="details" 
                    placeholder="Account Number & Title" 
                    className="bg-background"
                    value={details}
                    onChange={(e) => setDetails(e.target.value)}
                    required
                  />
                </div>

                <div className="p-4 bg-accent/5 rounded-lg border border-accent/20 flex gap-3">
                  <AlertCircle className="h-5 w-5 text-accent shrink-0" />
                  <p className="text-xs text-muted-foreground">
                    Withdrawals are processed 24/7. Maximum processing time is 2 hours. Ensure your account details are correct.
                  </p>
                </div>

                <Button type="submit" disabled={loading} className="w-full h-12 text-lg font-bold bg-primary hover:bg-primary/90 text-white">
                  {loading ? "Processing..." : "Submit Withdrawal Request"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
      <WhatsAppButton />
    </div>
  );
}
