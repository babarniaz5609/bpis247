
"use client";

import { useUser, useCollection, useFirestore } from "@/firebase";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownRight, Clock } from "lucide-react";
import { collection, query, where, orderBy } from "firebase/firestore";
import { useMemo } from "react";
import { cn } from "@/lib/utils";

export default function TransactionsPage() {
  const { user } = useUser();
  const db = useFirestore();

  const depositsQuery = useMemo(() => {
    if (!db || !user) return null;
    return query(collection(db, "deposits"), where("uid", "==", user.uid), orderBy("timestamp", "desc"));
  }, [db, user]);

  const withdrawalsQuery = useMemo(() => {
    if (!db || !user) return null;
    return query(collection(db, "withdrawals"), where("uid", "==", user.uid), orderBy("timestamp", "desc"));
  }, [db, user]);

  const { data: deposits } = useCollection(depositsQuery);
  const { data: withdrawals } = useCollection(withdrawalsQuery);

  const allTransactions = useMemo(() => {
    const combined = [
      ...(deposits?.map(d => ({ ...d, type: 'Deposit' })) || []),
      ...(withdrawals?.map(w => ({ ...w, type: 'Withdrawal' })) || [])
    ];
    return combined.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [deposits, withdrawals]);

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      <header className="py-12 bg-secondary/20 border-b border-white/5">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-headline font-bold text-white mb-2">Transaction History</h1>
          <p className="text-muted-foreground">Keep track of your deposits and withdrawals.</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {allTransactions.length > 0 ? (
              allTransactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-6 border-b border-white/5 hover:bg-white/5 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-full flex items-center justify-center",
                      tx.type === 'Deposit' ? "bg-primary/10" : "bg-destructive/10"
                    )}>
                      {tx.type === 'Deposit' ? <ArrowUpRight className="h-6 w-6 text-primary" /> : <ArrowDownRight className="h-6 w-6 text-destructive" />}
                    </div>
                    <div>
                      <p className="text-lg font-bold text-white">{tx.type} via {tx.method}</p>
                      <p className="text-sm text-muted-foreground">{new Date(tx.timestamp).toLocaleString()}</p>
                      {tx.type === 'Deposit' && <p className="text-xs font-mono text-muted-foreground">TID: {tx.tid}</p>}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-white">PKR {tx.amount.toLocaleString()}</p>
                    <Badge variant="outline" className={cn(
                      "text-xs uppercase px-3 py-1 mt-2",
                      tx.status === 'approved' ? "text-primary border-primary/20 bg-primary/5" : 
                      tx.status === 'pending' ? "text-amber-500 border-amber-500/20 bg-amber-500/5" :
                      "text-destructive border-destructive/20 bg-destructive/5"
                    )}>
                      {tx.status}
                    </Badge>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-20 text-center text-muted-foreground italic">
                You haven't made any transactions yet.
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
