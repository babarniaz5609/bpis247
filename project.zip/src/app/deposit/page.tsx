
"use client";

import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { Wallet, Smartphone, Landmark, Coins, Image as ImageIcon, AlertCircle, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";

const METHODS = [
  { id: 'jazzcash', name: 'JazzCash', icon: Smartphone, color: 'text-amber-500', account: '03123456789', holder: 'Admin OE' },
  { id: 'easypaisa', name: 'Easypaisa', icon: Smartphone, color: 'text-green-500', account: '03012345678', holder: 'Admin OE' },
  { id: 'bank', name: 'Bank Transfer', icon: Landmark, color: 'text-blue-500', account: '1234-5678-9012', holder: 'Open Exchange PK' },
  { id: 'crypto', name: 'USDT (TRC20)', icon: Coins, color: 'text-emerald-500', account: 'TRC20-ADDR-XXXX-XXXX', holder: 'Crypto OE' }
];

export default function DepositPage() {
  const [selectedMethod, setSelectedMethod] = useState(METHODS[0]);
  const [amount, setAmount] = useState("");
  const [tid, setTid] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !tid) {
      toast({
        title: "Error",
        description: "Please fill all required fields.",
        variant: "destructive"
      });
      return;
    }
    toast({
      title: "Success",
      description: "Deposit request submitted. Please wait for verification.",
    });
    setAmount("");
    setTid("");
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <Wallet className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-headline font-bold text-white">Deposit Funds</h1>
              <p className="text-muted-foreground">Add balance to your Open Exchange account.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Payment Method Selection */}
            <div className="space-y-6">
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="text-lg">1. Choose Payment Method</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup 
                    defaultValue="jazzcash" 
                    onValueChange={(v) => setSelectedMethod(METHODS.find(m => m.id === v) || METHODS[0])}
                    className="grid grid-cols-1 gap-3"
                  >
                    {METHODS.map((method) => (
                      <Label
                        key={method.id}
                        htmlFor={method.id}
                        className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all cursor-pointer ${
                          selectedMethod.id === method.id ? "border-primary bg-primary/5" : "border-white/5 bg-white/5 hover:border-white/10"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <RadioGroupItem value={method.id} id={method.id} className="sr-only" />
                          <div className={`p-2 rounded-lg bg-background ${method.color}`}>
                            <method.icon className="h-5 w-5" />
                          </div>
                          <span className="font-bold text-white">{method.name}</span>
                        </div>
                        {selectedMethod.id === method.id && <CheckCircle2 className="h-5 w-5 text-primary" />}
                      </Label>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              <Card className="glass-card border-accent/20">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-accent" />
                    Account Details
                  </CardTitle>
                  <CardDescription>Send payment to this account</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-background rounded-lg border border-white/10">
                    <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Account Holder</p>
                    <p className="text-lg font-bold text-white">{selectedMethod.holder}</p>
                  </div>
                  <div className="p-4 bg-background rounded-lg border border-white/10 flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Account Number</p>
                      <p className="text-lg font-bold text-white font-mono">{selectedMethod.account}</p>
                    </div>
                    <Button variant="ghost" size="sm" className="text-primary">Copy</Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Submission Form */}
            <div>
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="text-lg">2. Submit Transaction Info</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="amount">Deposit Amount (PKR)</Label>
                      <Input 
                        id="amount" 
                        type="number" 
                        placeholder="Min 500" 
                        className="bg-background"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="tid">Transaction ID / Reference Number</Label>
                      <Input 
                        id="tid" 
                        placeholder="Enter the TID from your app" 
                        className="bg-background font-mono"
                        value={tid}
                        onChange={(e) => setTid(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Screenshot of Payment</Label>
                      <div className="border-2 border-dashed border-white/10 rounded-xl p-8 flex flex-col items-center justify-center bg-background/50 hover:bg-background transition-colors cursor-pointer group">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                          <ImageIcon className="h-6 w-6 text-primary" />
                        </div>
                        <p className="text-sm font-medium text-white">Click to upload screenshot</p>
                        <p className="text-xs text-muted-foreground mt-1">PNG, JPG up to 5MB</p>
                      </div>
                    </div>

                    <Button type="submit" className="w-full h-12 text-lg font-bold bg-primary hover:bg-primary/90 text-white shadow-lg">
                      Confirm Deposit Request
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <WhatsAppButton />
    </div>
  );
}
