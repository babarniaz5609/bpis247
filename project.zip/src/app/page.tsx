
import { Play, ShieldCheck, Wallet, Trophy, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b border-white/5 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-40">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center font-headline font-bold text-white">OE</div>
            <span className="text-xl font-headline font-bold text-white">OPEN<span className="text-primary">EXCHANGE</span></span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/auth/login">
              <Button variant="ghost" className="text-white hover:text-primary">Login</Button>
            </Link>
            <Link href="/auth/register">
              <Button className="bg-primary text-white hover:bg-primary/90">Sign Up</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(0,153,51,0.15),transparent)] pointer-events-none" />
          <div className="container mx-auto px-4 relative z-10 text-center">
            <h1 className="text-5xl md:text-7xl font-headline font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-white/70">
              The Most Trusted <br /> <span className="text-primary">Betting Exchange</span>
            </h1>
            <p className="text-lg text-muted-foreground mb-10 max-w-2xl mx-auto">
              Experience lightning-fast deposits, instant withdrawals, and the best odds in the market. Join thousands of winners on Open Exchange today.
            </p>
            
            <div className="flex flex-col items-center gap-6">
              <a 
                href="https://bpexch.live/Users/Login" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group"
              >
                <Button size="lg" className="h-16 px-10 text-xl font-headline font-bold bg-primary hover:bg-primary/90 text-white rounded-full shadow-[0_0_20px_rgba(0,153,51,0.3)] group-hover:shadow-[0_0_30px_rgba(0,153,51,0.5)] transition-all">
                  <Play className="mr-3 fill-current" />
                  Play on BP Exchange
                </Button>
              </a>
              <p className="text-sm text-muted-foreground italic">
                Use your own BP Exchange ID and password provided by support.
              </p>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-20 bg-secondary/30">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="glass-card border-none">
                <CardContent className="pt-8">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-6">
                    <ShieldCheck className="text-primary w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-headline font-bold mb-3">Secure & Fair</h3>
                  <p className="text-muted-foreground">Certified gaming environment with advanced encryption to protect your data and funds.</p>
                </CardContent>
              </Card>
              
              <Card className="glass-card border-none">
                <CardContent className="pt-8">
                  <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mb-6">
                    <Wallet className="text-accent w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-headline font-bold mb-3">Fast Payouts</h3>
                  <p className="text-muted-foreground">Withdraw your winnings instantly through JazzCash, Easypaisa, Bank Transfer, or Crypto.</p>
                </CardContent>
              </Card>

              <Card className="glass-card border-none">
                <CardContent className="pt-8">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-6">
                    <Trophy className="text-primary w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-headline font-bold mb-3">Best Odds</h3>
                  <p className="text-muted-foreground">We provide the most competitive odds for sports, horse racing, and casino games.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-12 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div>
              <h4 className="font-headline font-bold mb-4 text-white">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/rules" className="hover:text-primary transition-colors">About Us</Link></li>
                <li><Link href="/rules" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
                <li><Link href="/rules" className="hover:text-primary transition-colors">Terms & Conditions</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-headline font-bold mb-4 text-white">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/support" className="hover:text-primary transition-colors">Contact Support</Link></li>
                <li><Link href="/rules" className="hover:text-primary transition-colors">Rules & Regulations</Link></li>
                <li><Link href="/rules" className="hover:text-primary transition-colors">Responsible Gaming</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-headline font-bold mb-4 text-white">Payments</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>JazzCash</li>
                <li>Easypaisa</li>
                <li>Bank Transfer</li>
                <li>USDT / BTC</li>
              </ul>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded flex items-center justify-center font-headline font-bold text-white text-xs">OE</div>
                <span className="text-lg font-headline font-bold text-white">OPEN<span className="text-primary">EXCHANGE</span></span>
              </div>
              <p className="text-xs text-muted-foreground">© 2024 Open Exchange. All rights reserved. Play responsibly.</p>
            </div>
          </div>
        </div>
      </footer>

      <WhatsAppButton />
    </div>
  );
}
