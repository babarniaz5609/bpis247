
"use client";

import { useState } from "react";
import { aiRuleExplainer } from "@/ai/flows/ai-rule-explainer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, BrainCircuit, ShieldAlert, BookOpen, AlertCircle } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

const POLICIES = [
  "Sports Betting Rules: All bets are final. Match results are determined by the official governing body of the sport. Abandoned matches result in void bets unless results are already established.",
  "Horse Racing Rules: Bets are settled on the official 'First Past the Post' result. Each-way terms depend on the number of runners.",
  "Casino Rules: RTP (Return to Player) is fixed. Malfunctions void all pays and plays. All outcomes are RNG-based.",
  "Deposit Rules: Minimum deposit is 500 PKR. Screenshot proof is mandatory. Verification takes 5-30 minutes.",
  "Withdrawal Rules: Withdrawals are processed 24/7. Maximum processing time is 2 hours. Minimum withdrawal is 1000 PKR.",
  "Responsible Gaming: Users can request self-exclusion. We monitor for addictive patterns. Underage gambling is strictly prohibited.",
  "Fraud Prevention: Multiple accounts are banned. Arbitrage betting may lead to account suspension. IP monitoring is active.",
  "Privacy Policy: We protect your data with SSL encryption. Financial details are never shared with third parties."
];

export default function RulesPage() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleAskAI() {
    if (!question) return;
    setLoading(true);
    try {
      const result = await aiRuleExplainer({ question, policies: POLICIES });
      setAnswer(result.answer);
    } catch (error) {
      setAnswer("Sorry, I encountered an error. Please try again or contact support.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="py-12 border-b border-white/5 bg-secondary/20">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-headline font-bold text-white mb-2">Rules & Regulations</h1>
          <p className="text-muted-foreground">Clear guidelines for a transparent betting experience.</p>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="betting" className="w-full">
              <TabsList className="grid grid-cols-2 md:grid-cols-4 bg-card mb-8">
                <TabsTrigger value="betting">Sports</TabsTrigger>
                <TabsTrigger value="finance">Finance</TabsTrigger>
                <TabsTrigger value="safety">Safety</TabsTrigger>
                <TabsTrigger value="privacy">Privacy</TabsTrigger>
              </TabsList>
              
              <TabsContent value="betting">
                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="text-primary h-5 w-5" />
                      Sports Betting Rules
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
                    <p>1. The minimum age for gambling is 18 years.</p>
                    <p>2. Bets can only be placed through the official interface.</p>
                    <p>3. Odds are subject to change until the bet is confirmed.</p>
                    <p>4. In-play betting results are based on the final whistle result including injury time but excluding extra time unless specified.</p>
                    <p>5. If a game is postponed or cancelled, all bets are void unless played within 24 hours.</p>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="finance">
                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Search className="text-accent h-5 w-5" />
                      Deposit & Withdrawal Rules
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-muted-foreground">
                    <div className="p-4 bg-primary/5 rounded-lg border border-primary/10">
                      <h4 className="font-bold text-white mb-2">Deposits</h4>
                      <p>Minimum: 500 PKR | Maximum: 1,000,000 PKR</p>
                      <p>Available: JazzCash, Easypaisa, Bank Transfer, USDT</p>
                    </div>
                    <div className="p-4 bg-accent/5 rounded-lg border border-accent/10">
                      <h4 className="font-bold text-white mb-2">Withdrawals</h4>
                      <p>Minimum: 1,000 PKR | Maximum: Unlimited</p>
                      <p>Processing Time: Instant to 2 hours.</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="safety">
                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ShieldAlert className="text-destructive h-5 w-5" />
                      Fraud Prevention
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-muted-foreground">
                    <p>Open Exchange maintains a zero-tolerance policy towards fraud. This includes but is not limited to:</p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Multiple accounts by a single user.</li>
                      <li>Collaborative play or syndicate betting.</li>
                      <li>Use of automated software or bots.</li>
                      <li>Money laundering activities.</li>
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="privacy">
                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle>Privacy & Data Protection</CardTitle>
                  </CardHeader>
                  <CardContent className="text-muted-foreground">
                    <p>We use military-grade encryption to secure your transactions and personal identity. We do not sell data to any third party under any circumstances.</p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* AI Explainer Sidebar */}
          <div className="lg:col-span-1">
            <Card className="glass-card border-primary/20 bg-primary/5 sticky top-24">
              <CardHeader>
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mb-2">
                  <BrainCircuit className="text-primary h-6 w-6" />
                </div>
                <CardTitle>AI Rule Explainer</CardTitle>
                <CardDescription>Confused? Ask our AI assistant about any policy.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input 
                    placeholder="e.g. How do I withdraw?" 
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    className="bg-background border-white/10"
                  />
                  <Button onClick={handleAskAI} disabled={loading} className="bg-primary hover:bg-primary/90">
                    {loading ? "..." : "Ask"}
                  </Button>
                </div>

                {answer && (
                  <div className="mt-4 p-4 rounded-lg bg-background/50 border border-white/5 animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center gap-2 text-primary font-bold mb-1 text-xs uppercase tracking-wider">
                      <AlertCircle className="h-3 w-3" />
                      AI Answer
                    </div>
                    <p className="text-sm text-white leading-relaxed">{answer}</p>
                  </div>
                )}

                <div className="pt-4 border-t border-white/5 mt-4">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mb-2">Try asking:</p>
                  <div className="flex flex-wrap gap-2">
                    <button 
                      onClick={() => setQuestion("What is the minimum deposit?")}
                      className="text-xs py-1 px-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors text-muted-foreground"
                    >
                      Min Deposit?
                    </button>
                    <button 
                      onClick={() => setQuestion("Can I have two accounts?")}
                      className="text-xs py-1 px-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors text-muted-foreground"
                    >
                      Double accounts?
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <WhatsAppButton />
    </div>
  );
}
