
"use client";

import { useUser, useDoc, useFirestore } from "@/firebase";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Mail, Phone, Shield, Calendar, Trophy, Share2, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

export default function ProfilePage() {
  const { user } = useUser();
  const { toast } = useToast();
  const userDoc = useDoc(user ? `users/${user.uid}` : null);
  const profile = userDoc?.data;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Code copied to clipboard.",
    });
  };

  if (!user) return <div className="p-20 text-center">Loading profile...</div>;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          <header className="flex flex-col md:flex-row items-center gap-6 p-8 glass-card rounded-2xl border-white/10">
            <div className="w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center text-4xl font-headline font-bold text-primary border-4 border-primary/10">
              {profile?.name?.substring(0, 1).toUpperCase()}
            </div>
            <div className="text-center md:text-left flex-grow">
              <div className="flex flex-col md:flex-row md:items-center gap-2 mb-2">
                <h1 className="text-3xl font-headline font-bold text-white">{profile?.name}</h1>
                <Badge className="bg-primary/20 text-primary border-primary/20 w-fit">
                  {profile?.role?.toUpperCase()}
                </Badge>
              </div>
              <p className="text-muted-foreground flex items-center justify-center md:justify-start gap-2">
                <Mail className="h-4 w-4" /> {profile?.email}
              </p>
            </div>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  Account Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between py-2 border-b border-white/5">
                  <span className="text-muted-foreground">User ID</span>
                  <span className="text-white font-mono">{user.uid.substring(0, 12)}...</span>
                </div>
                <div className="flex justify-between py-2 border-b border-white/5">
                  <span className="text-muted-foreground text-sm flex items-center gap-2">
                    <Phone className="h-4 w-4" /> Phone
                  </span>
                  <span className="text-white">{profile?.phone || "Not Set"}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-white/5">
                  <span className="text-muted-foreground text-sm flex items-center gap-2">
                    <Calendar className="h-4 w-4" /> Joined
                  </span>
                  <span className="text-white">
                    {profile?.createdAt ? new Date(profile.createdAt.seconds * 1000).toLocaleDateString() : "N/A"}
                  </span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-muted-foreground text-sm flex items-center gap-2">
                    <Shield className="h-4 w-4" /> Security
                  </span>
                  <Badge variant="outline" className="text-primary border-primary/20">Verified</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-accent/20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-accent" />
                  Rewards & Referrals
                </CardTitle>
                <CardDescription>Share your code to earn bonuses.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-6 bg-accent/5 rounded-xl border border-accent/10 text-center">
                  <p className="text-xs text-muted-foreground uppercase tracking-widest mb-2">My Referral Code</p>
                  <div className="flex items-center justify-center gap-3">
                    <p className="text-3xl font-headline font-bold text-white">{profile?.referralCode || "NONE"}</p>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      onClick={() => copyToClipboard(profile?.referralCode || "")}
                      className="text-primary hover:bg-primary/10"
                    >
                      <Copy className="h-5 w-5" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Share2 className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white">Referral Bonus</p>
                        <p className="text-xs text-muted-foreground">Earn 5% on every deposit of your friend.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
