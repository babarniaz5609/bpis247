# Open Exchange - Premium Betting Platform

This is a modern, professional betting exchange platform built with Next.js, Firebase, and ShadCN UI.

## Features
- **User Dashboard**: Real-time balance and transaction history.
- **Admin Panel**: Complete control over deposits, withdrawals, and user management.
- **Play ID System**: Assign exchange credentials to users.
- **WhatsApp Support**: Built-in floating support button.

## How to push to GitHub

Follow these steps in your terminal to upload this code to GitHub:

1. **Initialize Git**:
   ```bash
   git init
   ```

2. **Add all files**:
   ```bash
   git add .
   ```

3. **Commit your changes**:
   ```bash
   git commit -m "Initial commit: Open Exchange Complete Platform"
   ```

4. **Create a repository on GitHub**:
   Go to [github.com/new](https://github.com/new) and create a new repository.

5. **Connect and Push**:
   Copy the URL of your new repository and run:
   ```bash
   git remote add origin <YOUR_GITHUB_REPO_URL>
   git branch -M main
   git push -u origin main
   ```

## Admin Access
Log in with `asif1asif7asof@gmail.com` to get automatic administrative privileges.
