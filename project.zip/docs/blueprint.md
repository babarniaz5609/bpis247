# **App Name**: Open Exchange

## Core Features:

- Supabase Secure Auth: Multi-role authentication system for admins and users using email/password, integrated with project reference wofrapotgmemnsldjbso.
- Finance Management Hub: Streamlined interface for initiating and tracking deposit and withdrawal requests with full history and account status display.
- Unified Admin Command Center: Comprehensive panel for managing user profiles, processing financial transactions, and configuring payment methods (JazzCash, Easypaisa, Crypto).
- Direct Play Integration: Quick-launch action button linking to bpexch.live external exchange platform in a dedicated browser tab.
- Support & Communication: Floating WhatsApp support button (+212782563750) and a real-time system announcement feed for critical updates.
- AI Rule Explainer Tool: A smart support tool powered by generative AI that helps users navigate complex betting and fraud prevention policies.
- Relational Financial Schema: Structured Supabase database implementing Row Level Security (RLS) policies for profiles, transactions, and payment methods.

## Style Guidelines:

- Primary Color: Forest Green (#009933), a vibrant yet professional hue signifying growth and prosperity in an exchange environment.
- Background Color: Obsidian Green (#0b0f0d), a deeply desaturated and dark base that provides a premium, high-contrast backdrop.
- Accent Color: Solar Lime-Gold (#85cc14), an analogous hue providing energetic highlights and contrast for secondary UI elements.
- Headline font: 'Poppins' for a precise, geometric, and fashionable avant-garde look. Body font: 'Inter' for a machined, objective, and neutral tone suitable for financial data.
- Minimalist gold-accented line icons for financial actions and sidebar navigation to maintain a high-end betting aesthetic.
- Responsive mobile-first layout featuring fixed-position elements for a betting-app feel and professional cards with subtle dark borders.
- Sleek CSS transitions for sidebar navigation and shimmering loading states for real-time transaction tables.